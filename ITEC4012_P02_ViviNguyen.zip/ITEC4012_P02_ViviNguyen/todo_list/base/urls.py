from django.conf.urls import url
from django.urls import path, include
from . views import (TaskList, TaskDetail, TaskCreate, TaskUpdate, DeleteTask, CustomLoginView, RegisterPage,
                     PublicPost, PublicDetail)
from django.contrib.auth.views import LogoutView

urlpatterns = [
    # display posts
    path('', TaskList.as_view(), name='tasks'),
    path('', PublicPost.as_view(), name='public'),

    # display details when link clicked
    path('task/<int:pk>/', TaskDetail.as_view(), name="task"),
    path('task/<int:pk>/', PublicDetail.as_view(), name="post"),

    # review system
    url(r'^reviews/', include('reviews.urls')),

    path('create-task/', TaskCreate.as_view(), name="task-create"),
    path('task-update/<int:pk>/', TaskUpdate.as_view(), name="task-update"),
    path('task-delete/<int:pk>/', DeleteTask.as_view(), name="task-delete"),

    path('login/', CustomLoginView.as_view(), name="login"),
    path('register/', RegisterPage.as_view(), name="register"),
    path('logout/', LogoutView.as_view(next_page="login"), name="logout"),

]